# Tareas-pendientes-Evelyn-Garcia-Osorio
Tareas de la semana 1 y 2
